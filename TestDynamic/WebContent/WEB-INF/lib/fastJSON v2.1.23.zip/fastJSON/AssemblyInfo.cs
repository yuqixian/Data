﻿using System.Reflection;


[assembly: AssemblyTitle("fastJSON")]
[assembly: AssemblyDescription("smallest fastest polymorphic json serializer")]
[assembly: AssemblyProduct("fastJSON")]
[assembly: AssemblyCopyright("2010-2016")]


[assembly: AssemblyVersion("2.1.0.0")]
[assembly: AssemblyFileVersion("2.1.23.0")]
